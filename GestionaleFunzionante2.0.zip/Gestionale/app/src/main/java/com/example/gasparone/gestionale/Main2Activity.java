package com.example.gasparone.gestionale;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;

public class Main2Activity extends AppCompatActivity {

    TextView textColore;
    JSONArray jsonArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textColore = findViewById(R.id.textView);
        String json = getIntent().getStringExtra("json");

        try {
            jsonArray = new JSONArray(json);

            textColore.setText("" + jsonArray.getJSONObject(0).get("modello"));

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}
