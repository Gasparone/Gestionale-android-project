package com.example.gasparone.gestionale;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.IccOpenLogicalChannelResponse;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    EditText textPsw;
    EditText textUsr;
    Button button;
    JSONArray jsonObj;
    String jsonStr = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        textPsw = findViewById(R.id.textPsw);
        textUsr = findViewById(R.id.textUsr);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetContacts g = new GetContacts();
                g.execute();
            }
        });

    }

    private class GetContacts extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this,"Connessione...",Toast.LENGTH_LONG).show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            // Making a request to url and getting response
            Log.i("User",textPsw.getText().toString());
            Log.i("Pass",textPsw.getText().toString());
            String url = "http://192.168.5.13/test.php?username=" + textUsr.getText().toString() + "&password=" + textPsw.getText().toString();
            jsonStr = sh.makeServiceCall(url);
            Log.i("Info", "" + jsonStr);
            //Log.e(TAG, "Response from url: " + jsonStr);
            if (jsonStr != null) {
                //jsonObj = new JSONArray(jsonStr);

            } else {
                Log.e("AIA", "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Intent intent = new Intent(MainActivity.this,Main2Activity.class);
            intent.putExtra("json", "" + jsonStr);
            startActivity(intent);
        }
    }
}
